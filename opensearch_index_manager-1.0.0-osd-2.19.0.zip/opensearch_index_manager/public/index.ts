import { OpenSearchIndexManagerPlugin } from './plugin';

export function plugin() {
  return new OpenSearchIndexManagerPlugin();
}

export { OpenSearchIndexManagerPlugin };
